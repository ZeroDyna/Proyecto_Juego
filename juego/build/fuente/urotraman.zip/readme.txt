Free for personal and commercial use

Urotraman is a font display, created to pay homage to the work of Eiji Tsuburaya, perfect for titles and giving power in his texts was millimetrically designed for different situations with 140+ gliphys between accents and symbols.

https://www.behance.net/rdgovargas

https://www.instagram.com/rdgovargas/

http://rodrigovargas.design/


